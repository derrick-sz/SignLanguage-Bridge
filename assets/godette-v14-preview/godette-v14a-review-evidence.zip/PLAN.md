# v14 controlled reference-fit exploration

Input: checksum-verified frozen v13 uploaded by the user. Original files are never modified.

The user explicitly asked for autonomous continued model/rig improvements and stage backups. This pass is isolated from the six-motion runtime audit.

1. Establish same-camera baseline views and retain the original native default.
2. Candidate A: curve the jacket hem by lifting lateral corners approximately 12 mm with all attached lower jacket trims/ornaments following; shorten trousers by lifting the cuff approximately 18 mm, with a long smooth falloff to mid-shin.
3. Candidate B: add a very shallow front/back pressed trouser crease (under 1 mm); accept only if it improves the rendered garment without hard artifacts.
4. Verify protected mesh/rig/default/weights/topology are unchanged, test original default, neutral standing, hip/knee stress and three continuous sweeps. Compare actual renders with the reference.
5. Preserve stage checkpoints and a compact archive with hashes. Do not overwrite any repository branch or remote asset. Report to the parent for coordinated GitHub backup.

No face, head proportions, hand geometry, bone rest, hierarchy, skinning weights, or native default pose changes are allowed in this pass. No claim of exact 1:1 matching or universal collision freedom.
