import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.env.THREE_ROOT||path.resolve('fusion_review/test-deps/node_modules/three');
export async function resolve(specifier,context,nextResolve){
 if(specifier==='three'||specifier==='/animation/vendor/three.module.js')return {url:pathToFileURL(path.join(root,'build/three.module.js')).href,shortCircuit:true};
 if(specifier.startsWith('/animation/vendor/jsm/'))return {url:pathToFileURL(path.join(root,'examples/jsm',specifier.slice('/animation/vendor/jsm/'.length))).href,shortCircuit:true};
 return nextResolve(specifier,context);
}
export async function load(url,context,nextLoad){if(url.startsWith(new URL('./',import.meta.url).href)&&url.includes('/runtime/')&&url.endsWith('.js'))return nextLoad(url,{...context,format:'module'});return nextLoad(url,context);}
