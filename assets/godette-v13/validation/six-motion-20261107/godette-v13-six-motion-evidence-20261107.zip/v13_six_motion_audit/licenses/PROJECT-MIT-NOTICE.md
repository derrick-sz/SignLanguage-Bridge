# Reused components

rig.js, retarget.js and stabilization.js are adapted from feifei9126/signbridge,
local revision 7ab6de3828aacf99aa758c68b5699089cb33ef75 (MIT).
The bridge additionally applies reversible source-space gesture/temporal
candidates, wrist retargeting, and calibrated jaw/lip driving. Original source
motion parameters are retained separately from those derived candidates.

MIT License

Copyright (c) 2026 SignBridge Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Three.js/GLTFLoader binaries, the Godette model and the six original motion sources are not redistributed here. Obtain authorized inputs and dependencies as described in README.md. Godette is attributed to zahlenmaler under CC BY 4.0. No language or motion-quality acceptance is implied.
