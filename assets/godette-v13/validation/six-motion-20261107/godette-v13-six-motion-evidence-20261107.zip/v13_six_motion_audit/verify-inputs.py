import json,hashlib,pathlib,math,zipfile
R=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
z=R/'inputs/dot-blender-handoff-20261106.zip';assert sha(z.read_bytes())=='fb5cd09cdc5896baa7ffaba998a1a6f7227ce9439a63cff0068dec6bbff623f7'
p=R/'handoff/HANDOFF-MANIFEST.json';assert sha(p.read_bytes())=='37f1602cb24476c4ff35706db49ec127e3bb9eb6035754b7cbb52013bdd3c638';manifest=json.loads(p.read_bytes())
with zipfile.ZipFile(z) as f:
 assert set(f.namelist())==set(manifest['files'])|{'HANDOFF-MANIFEST.json'}
 for n,e in manifest['files'].items():
  b=(R/'handoff'/n).read_bytes();assert b==f.read(n) and len(b)==e['bytes'] and sha(b)==e['sha256'],n
runtime=json.loads((R/'runtime-sources.json').read_bytes())
for e in runtime['files']:
 b=(R/'runtime'/e['path']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['git_blob_sha'],e['path']
preset=json.loads((R/'runtime/slbridge/animation/godette_v13_manifest.json').read_bytes());old=json.loads((R/'handoff/presentation/manifest.json').read_bytes());old={p['asset_id']:p for p in old['pilots']};clips=[]
for p in preset['pilots']:
 i=p['asset_id'];b=(R/'handoff/source'/f'{i}.json').read_bytes();d=json.loads(b);c=d['clip'];assert old[i]['source_motion_sha256']==p['source_motion_sha256'];assert old[i].get('temporal_profile')==p.get('temporal_profile');assert c['id']==i and c['text']==p['text'];assert len(d['parents'])==len(d['restJoints'])==55;assert d['parents'][0]==-1 and all(0<=k<j for j,k in enumerate(d['parents'][1:],1));assert len(c['poses'])==c['frames'] and c['fps']==25
 assert all(len(v)==3 and all(math.isfinite(x) for x in v) for v in d['restJoints']);assert all(len(f)==55 and all(len(v)==3 and all(math.isfinite(x) for x in v) for v in f) for f in c['poses'])
 clips.append({'id':i,'text':c['text'],'frames':c['frames'],'fps':c['fps'],'wrapper_sha256':sha(b),'registry_source_motion_sha256':p['source_motion_sha256'],'clip_source_video_sha256':c['source_sha256'],'temporal_profile':p.get('temporal_profile')})
assert len(clips)==len({p['id'] for p in clips})==6 and sum(p['frames'] for p in clips)==1138
out={'status':'PASS_INPUT_IDENTITY_ONLY','manifest_sha256':sha((R/'handoff/HANDOFF-MANIFEST.json').read_bytes()),'archive_sha256':sha(z.read_bytes()),'checked_files':len(manifest['files']),'runtime_commit':runtime['commit'],'runtime_files_verified':len(runtime['files']),'clips':clips,'scope':'Wrapper bytes verified. Registry hashes match handoff and current preset; full source archive unavailable.'};(R/'handoff-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':out['status'],'files':out['checked_files'],'runtime_files':len(runtime['files']),'frames':1138}))
