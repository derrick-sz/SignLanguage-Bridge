# Equal/rest quaternion candidate (local only)

## Finding
Frozen v13 GLB (SHA256 2d89e2e33271d2e06c5a834a56675663aa5551814e2c98ef86fc084ca0c151a8), Three r170, pinned runtime cc11b4d6ed0f51e0d727a45a2f2aba71ea1e289f.
`interpolate` deliberately skips normalization for equal keys, but its fallback still invokes Three's slerp. Identical imported quaternions with squared norm below 1 enter its trigonometric branch (not its dot>=1 early return). The weighted sum then perturbs identical components.

Of 13 rig-mapped but retarget-unanimated keys, only chest/Spine_2_198 and neck3/Neck_3_130 changed at fractions .1, .25, .5, .75, .9. Maximum component drifts: 2.7436036775796424e-9 and 1.3416793898102242e-8. Hip_218 squared norm is exactly 1 and all tested fractions remain exact. All 13 keys and fraction deltas are in diagnosis-all.txt. Eleven other rig nodes also drift at .5 when deliberately supplied equal/rest keys; these are normally retarget-animated nodes.

## Minimal patch
`equal-rest.patch` adds an explicit equal-key copy branch before interpolation. Unequal keys retain the original logic. It does not normalize authored resting keys, modify GLB data, or change source quaternions.
Candidate module: web/rig.js SHA256 c886ff0441af0873e113ab4934b75b77dc8449af2a112ac2b2ea55c7681c1505.
Pinned module remains SHA256 4e3c5488fdd785b01689e158adbc34cd4ce5d61c80407b8b40cada2c999770f1.

## Reproduce (from workspace root)
node --no-warnings --experimental-loader ./v13_six_motion_audit/node-loader.mjs v13_six_motion_audit/equal_rest_candidate/regression.mjs --original
node --no-warnings --experimental-loader ./v13_six_motion_audit/node-loader.mjs v13_six_motion_audit/equal_rest_candidate/regression.mjs

Original: exit 1, expected exact-fallback assertion fails on chest at fraction .1 (`red.log`). Candidate: exit 0, 618 checks (`green.log`). Tests load the real frozen GLB through GLTFLoader, with texture decoding stubbed only. Checks cover all 53 mapped rig keys at seven fractions, separate equal under-unit/over-unit quaternion objects, exact endpoints, changing nonunit keys, antipodal shortest-path interpolation, unchanged input quaternions, 227 bones' complete resting local TRS, and unchanged GLB hash.

This candidate folder is not a full repository and has no project test command or original test suite. Full repository regression and the parent's six-motion audit remain separate verification work. No semantic, video, browser, collision, deployment, or arbitrary lower-body animation acceptance is claimed. Pinned runtime and parent's harness were not edited. No remote writes.
