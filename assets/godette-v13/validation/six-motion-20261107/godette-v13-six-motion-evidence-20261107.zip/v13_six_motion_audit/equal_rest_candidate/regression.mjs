import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import * as THREE from 'three';
import {GLTFLoader} from '/animation/vendor/jsm/loaders/GLTFLoader.js';
const {createHumanoidRig}=await import(process.argv.includes('--original')?'../runtime/slbridge/animation/web/rig.js':'./web/rig.js');
const root=new URL('../',import.meta.url);
const modelPath=new URL('inputs/uploaded-v13/godette-reference-v13.glb',root);
const bytes=fs.readFileSync(modelPath);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(sha(bytes),'2d89e2e33271d2e06c5a834a56675663aa5551814e2c98ef86fc084ca0c151a8');
assert.equal(THREE.REVISION,'170');
globalThis.self=globalThis;
const loader=new GLTFLoader();loader.register(()=>({name:'TEXTURE_STUB',loadTexture(){return Promise.resolve(new THREE.Texture())}}));
const model=(await loader.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'')).scene;
const profile=JSON.parse(fs.readFileSync(new URL('runtime/slbridge/animation/godette_v13_manifest.json',root))).rig_profile;
const rig=createHumanoidRig(model,profile,{avatarSha256:sha(bytes)});
const baseline=new Map();model.traverse(b=>{if(b.isBone)baseline.set(b.name,[...b.position,...b.quaternion,...b.scale])});
const delta=(a,b)=>Math.max(...a.map((v,i)=>Math.abs(v-b[i])));
const mapped=['neck','head','leftShoulder','rightShoulder','leftUpperArm','rightUpperArm','leftLowerArm','rightLowerArm','leftHand','rightHand'];for(const s of ['left','right'])for(const f of ['Thumb','Index','Middle','Ring','Little'])for(const x of f==='Thumb'?['Metacarpal','Proximal','Distal']:['Proximal','Intermediate','Distal'])mapped.push(s+f+x);
const defaults=Object.keys(rig.bones).filter(k=>!mapped.includes(k));
rig.interpolate({}, {}, .5);
const changed=Object.entries(rig.bones).map(([k,b])=>({key:k,name:b.name,normSquared:rig.rest[k].quaternion.lengthSq(),delta:delta(b.quaternion.toArray(),rig.rest[k].quaternion.toArray()),unanimated:defaults.includes(k)})).filter(x=>x.delta!==0);
console.log(JSON.stringify({defaultKeys:defaults,changed},null,2));
if(process.argv.includes('--diagnose')){
 const byDefault=defaults.map(k=>({key:k,name:rig.bones[k].name,normSquared:rig.rest[k].quaternion.lengthSq(),samples:[]}));
 for(const t of [.1,.25,.5,.75,.9]){rig.interpolate({}, {}, t);for(const row of byDefault)row.samples.push({t,delta:delta(rig.bones[row.key].quaternion.toArray(),rig.rest[row.key].quaternion.toArray())});}
 console.log(JSON.stringify({defaultDiagnostics:byDefault},null,2));process.exit(0);
}
let cases=0;
for(const t of [0,.1,.25,.5,.75,.9,1]){
 rig.interpolate({}, {}, t);
 for(const [k,b] of Object.entries(rig.bones)){assert.deepEqual(b.quaternion.toArray(),rig.rest[k].quaternion.toArray(),`Fallback exact ${k}/${b.name} at ${t}`);cases++;}
}
// Separate equal objects, both under-unit and over-unit, reproduce imported keys.
const key='leftUpperArm',bone=rig.bones[key];
for(const scale of [1-1e-8,1+1e-8])for(const t of [0,.1,.5,.9,1]){
 const q=new THREE.Quaternion(.1,.2,.3,.9).normalize();q.set(...q.toArray().map(v=>v*scale));
 const from={[key]:q},to={[key]:q.clone()},before=JSON.stringify([from,to]);
 rig.interpolate(from,to,t);assert.deepEqual(bone.quaternion.toArray(),q.toArray());assert.equal(JSON.stringify([from,to]),before);cases++;
}
// Changing non-unit keys still interpolate using normalized detached keys; endpoints retain exact components.
for(const antipodal of [false,true])for(const t of [0,.1,.5,.9,1]){
 const a=new THREE.Quaternion(.1,.2,.3,.9),b=antipodal?new THREE.Quaternion(-.1,-.2,-.3,-.9):new THREE.Quaternion(.5,.2,-.1,.8);
 const before=JSON.stringify([a,b]);const expected=t===0?a:t===1?b:a.clone().normalize().slerp(b.clone().normalize(),t);
 rig.interpolate({[key]:a},{[key]:b},t);assert.deepEqual(bone.quaternion.toArray(),expected.toArray());assert.equal(JSON.stringify([a,b]),before);cases++;
}
rig.reset();rig.interpolate({}, {}, .5);
model.traverse(b=>{if(b.isBone){assert.deepEqual([...b.position,...b.quaternion,...b.scale],baseline.get(b.name));cases++;}});
assert.equal(sha(fs.readFileSync(modelPath)),sha(bytes));
console.log(JSON.stringify({status:'PASS',cases,allBones:baseline.size,defaultKeys:defaults.length,sourceGLBUnchanged:true}));
