import hashlib,json,pathlib
root=pathlib.Path(__file__).parent
expected=dict(
 animation_interpolation='ba9fc38f4cf0b10da81d3404998dbcbe4e70d97f',
 animation_godette_v13_glb='018565d2965c1ff13212f629d8f3f5b6303e0d90',
 animation_godette_v12_glb='101c779ed9d70b5cda6082be6d51b4d169e04078',
 animation_stage='af2ffa8937bc22e45b23083fa77697c7015c1f56',
 animation_expression='e2bc24a5af059039e50fe0e6a1b69c459b61fed3',
 animation_nonmanual_rig='065375c96614c3c25852ee9937b1a1b1432a355e',
 animation_godette_v11='3f426739f2354409681a6f868aa9049c3fac628b',
 animation_godette_v11_glb='a97a4fa492bb884670ba60cbe43f8a7453cdb2b2',
 animation_nonmanual='a608240027bb1cab805053c30ed29956566db853',
 animation_nonmanual_stage='5030527abf48d1f09a27898317689916a3a30d00',
 animation_geometry='6d69ba0a1da5180dae2e7361eee1e1d821479497',
 animation_godette_v12='16c4d8cdcfa37f77338d70139dc1e11af9574264',
 animation_godette_v13='bc17aecb0a82de32b1fc7831a0dd00348bdff5d2')
files=[]
for name,wanted in expected.items():
 p=f'tests/{name}.test.mjs';b=(root/'repo'/p).read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert actual==wanted,(p,actual,wanted)
 files.append(dict(path=p,git_blob_sha=actual,sha256=hashlib.sha256(b).hexdigest()))
runtime=json.loads((root.parent/'runtime-sources.json').read_text())
for row in runtime['files']:
 p=root/'repo'/row['path']
 if not p.exists() or row['path'].endswith('/rig.js'): continue
 b=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert actual==row['git_blob_sha'],row['path']
 files.append(dict(path=row['path'],git_blob_sha=actual))
report=dict(repository='betterway614/SignLanguage-Bridge',commit=runtime['commit'],exact_pinned_tests=13,files=files,candidate_rig_sha256=hashlib.sha256((root/'repo/slbridge/animation/web/rig.js').read_bytes()).hexdigest())
(root/'frontend-source-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: 13 exact pinned test blobs and copied runtime dependencies verified')
