#!/usr/bin/env bash
set -eu
HERE=$(cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
export ANIMATION_THREE_MODULE="$ROOT/fusion_review/test-deps/node_modules/three/build/three.module.js"
export ANIMATION_GLTF_LOADER="$ROOT/fusion_review/test-deps/node_modules/three/examples/jsm/loaders/GLTFLoader.js"
export ANIMATION_V13_AVATAR_GLB="$ROOT/v13_six_motion_audit/inputs/uploaded-v13/godette-reference-v13.glb"
export ANIMATION_V11_AVATAR_GLB="$ROOT/fusion_recovery/godette-reference-model-v11-20261106/godette_delivery_v11/godette-reference-v11.glb"
export ANIMATION_AVATAR_GLB="$ROOT/v13_six_motion_audit/handoff/presentation/avatar-clean.glb"
export ANIMATION_V13_REPORT_DIR="$HERE/mouth-report"
unset ANIMATION_V12_AVATAR_GLB
node --test "$HERE"/repo/tests/*.test.mjs
